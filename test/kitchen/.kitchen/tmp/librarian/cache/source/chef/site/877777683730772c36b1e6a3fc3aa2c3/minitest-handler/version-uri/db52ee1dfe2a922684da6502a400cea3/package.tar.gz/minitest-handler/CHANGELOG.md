Changelog
=====

### v0.0.9

* add windows support tks to David Petzel
* add travis-ci integration
* change maintainer to Bryan W. Berry

	
### v0.0.7

* Add better examples to the readme 
* pass foodcritic
	
### v0.0.6

* MINITEST-HANDLER-COOKBOOK-12 ensure minitest gem used and not the standard library in 1.9
* MINITEST-HANDLER-COOKBOOK-11 Add support for Chef-Solo
* Create the /var/chef/minitest directory if it doesn't already exist


### v0.0.5 

* Install the minitest-chef-handler gem instead of downloading from github directly
* Remove tests from cookbooks no longer in the run list

### v0.0.4

Add examples/ top level directory (may not work)
